class Config:
    DEBUG = False
    JSON_SORT_KEYS = False
    RATELIMIT_DEFAULT = "10 per minute"